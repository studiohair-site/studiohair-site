Instruções para uso do site Studio Hair:

1. Abra o arquivo index.html em qualquer navegador (computador ou celular).
2. Clique em "Área do Admin" e insira a senha inicial: studio123.
3. No painel, altere as informações do salão, serviços, foto e contatos.
4. Para publicar online:
   - Hostinger: envie o arquivo index.html para a pasta public_html do seu domínio.
   - GitHub Pages: crie um repositório e envie o arquivo index.html, depois ative GitHub Pages nas configurações.

Todos os dados são salvos localmente no navegador. Se quiser centralizar tudo em um servidor, será preciso criar um back-end.
